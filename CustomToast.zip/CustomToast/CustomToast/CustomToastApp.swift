//
//  CustomToastApp.swift
//  CustomToast
//
//  Created by Nick Joliya on 22/11/24.
//

import SwiftUI

@main
struct CustomToastApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
