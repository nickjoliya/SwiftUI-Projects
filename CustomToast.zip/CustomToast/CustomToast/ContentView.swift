//
//  ContentView.swift
//  CustomToast
//
//  Created by Nick Joliya on 22/11/24.
//

import SwiftUI

struct ContentView: View {
    @State private var isToastVisible = false
    @State private var toastType: ToastType = .success

    var body: some View {
        ZStack {
            // Background color and gradient effect
            LinearGradient(
                gradient: Gradient(colors: [Color.blue.opacity(0.3), Color.purple.opacity(0.3)]),
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack(spacing: 20) {
                CustomButton(
                    title: "Show Success Toast",
                    gradient: Gradient(colors: [Color.green, Color.teal]),
                    icon: "checkmark.circle",
                    action: { showToast(type: .success) }
                )

                CustomButton(
                    title: "Show Error Toast",
                    gradient: Gradient(colors: [Color.red, Color.orange]),
                    icon: "xmark.circle",
                    action: { showToast(type: .error) }
                )

                CustomButton(
                    title: "Show Info Toast",
                    gradient: Gradient(colors: [Color.blue, Color.cyan]),
                    icon: "info.circle",
                    action: { showToast(type: .info) }
                )

                CustomButton(
                    title: "Show Warning Toast",
                    gradient: Gradient(colors: [Color.yellow, Color.orange]),
                    icon: "exclamationmark.triangle",
                    action: { showToast(type: .warning) }
                )
                
                Spacer()
            }
            
            // Custom Toast Overlay
            if isToastVisible {
                CustomToast(
                    message: "This is a \(toastType) toast!",
                    type: toastType,
                    duration: 3,
                    onTap: {
                        print("Toast tapped!")
                    },
                    isShowing: $isToastVisible
                )
                .transition(.move(edge: .top).combined(with: .opacity)) // Toast comes from top
                .zIndex(1) // Make sure it's on top of other UI elements
            }
        }
    }

    private func showToast(type: ToastType) {
        toastType = type
        withAnimation {
            isToastVisible = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            withAnimation {
                isToastVisible = false
            }
        }
    }
}

struct CustomButton: View {
    let title: String
    let gradient: Gradient
    let icon: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon)
                    .font(.headline)
                    .foregroundColor(.white)
                Text(title)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(
                LinearGradient(gradient: gradient, startPoint: .leading, endPoint: .trailing)
            )
            .cornerRadius(8)
            .shadow(color: .black.opacity(0.2), radius: 8, x: 0, y: 4)
        }
        .padding(.horizontal, 80)
    }
}

enum ToastType {
    case success, error, info, warning

    var backgroundGradient: LinearGradient {
        switch self {
        case .success:
            return LinearGradient(colors: [Color.green.opacity(0.8), Color.green],
                                  startPoint: .topLeading,
                                  endPoint: .bottomTrailing)
        case .error:
            return LinearGradient(colors: [Color.red.opacity(0.8), Color.red],
                                  startPoint: .topLeading,
                                  endPoint: .bottomTrailing)
        case .info:
            return LinearGradient(colors: [Color.blue.opacity(0.8), Color.blue],
                                  startPoint: .topLeading,
                                  endPoint: .bottomTrailing)
        case .warning:
            return LinearGradient(colors: [Color.orange.opacity(0.8), Color.orange],
                                  startPoint: .topLeading,
                                  endPoint: .bottomTrailing)
        }
    }

    var icon: String {
        switch self {
        case .success: return "checkmark.circle.fill"
        case .error: return "xmark.circle.fill"
        case .info: return "info.circle.fill"
        case .warning: return "exclamationmark.triangle.fill"
        }
    }
}

struct CustomToast: View {
    let message: String
    let type: ToastType
    let duration: Double
    let onTap: (() -> Void)?
    @Binding var isShowing: Bool

    @State private var scale: CGFloat = 0.9
    @State private var opacity: Double = 0.0
    @State private var offsetY: CGFloat = -100

    var body: some View {
        if isShowing {
            VStack {
                Spacer() // Push to the top of the screen

                HStack(spacing: 12) {
                    // Icon
                    Image(systemName: type.icon)
                        .font(.largeTitle)
                        .foregroundColor(.white)
                        .scaleEffect(scale) // Animate scale
                        .opacity(opacity) // Animate opacity
                        .shadow(radius: 5)

                    // Message
                    Text(message)
                        .font(.headline)
                        .foregroundColor(.white)
                        .multilineTextAlignment(.leading)
                        .lineLimit(2)
                        .scaleEffect(scale) // Animate scale
                        .opacity(opacity)
                }
                .padding(.vertical, 10)
                .frame(maxWidth: .infinity)
                .background(
                    RoundedRectangle(cornerRadius: 30)
                        .fill(type.backgroundGradient)
                        .shadow(color: .black.opacity(0.3), radius: 8, x: 0, y: 4)
                )
                .padding(.horizontal, 20)
                .offset(y: offsetY) // Animate translation
                .onTapGesture {
                    onTap?()
                    withAnimation {
                        isShowing = false
                    }
                }
                .onAppear {
                    withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
                        scale = 1.0
                        opacity = 1.0
                        offsetY = 0
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
                        withAnimation(.easeOut(duration: 0.3)) {
                            isShowing = false
                        }
                    }
                }
                .onDisappear {
                    // Reset animations for next appearance
                    scale = 0.9
                    opacity = 0.0
                    offsetY = -100
                }
            }
            .transition(.move(edge: .top).combined(with: .opacity)) // Toast comes from top
        }
    }
}


#Preview {
    ContentView()
}
