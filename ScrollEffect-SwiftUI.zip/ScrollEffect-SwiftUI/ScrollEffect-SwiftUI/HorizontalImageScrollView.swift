//
//  HorizontalImageScrollView.swift
//  ScrollEffect-SwiftUI
//
//  Created by Nick Joliya on 06/12/24.
//


import SwiftUI

struct HorizontalImageScrollView: View {
    
    let imageNames = ["Luffy", "Nami", "Sanji", "Zoro" ,"Ussop" , "Robin" , "Chopper"]
    
    var body: some View {
        ZStack{
            Color.orange.opacity(0.6).ignoresSafeArea()
            GeometryReader { proxy in
                let size = proxy.size
                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHStack(spacing: 0) {
                        ForEach(imageNames, id: \.self) { imageName in
                            Image(imageName)
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 220, height: size.height)
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                                .scrollTransition(.interactive , axis: .horizontal){ content , phase in
                                    content
                                        .blur(radius: phase.isIdentity ? 0 : 7 ,opaque: false)
                                        .scaleEffect(phase.isIdentity ? 1 : 0.8 ,anchor: .bottom)
                                        .offset(y: phase.isIdentity ? 0 : 35)
                                        .rotationEffect(.init(degrees: phase == .identity ? 0 : phase.value * 15), anchor: .bottom)
                                    
                                }
                        }
                    }
                    .scrollTargetLayout()
                }
                
                .scrollClipDisabled()
                .scrollTargetBehavior(.viewAligned(limitBehavior: .always))
                .safeAreaPadding(.horizontal, (size.width - 220) / 2)
            }
            .frame(height: 330)
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
