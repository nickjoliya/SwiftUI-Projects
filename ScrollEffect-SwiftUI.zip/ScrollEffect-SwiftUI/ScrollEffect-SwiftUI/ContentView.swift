//
//  ContentView.swift
//  ScrollEffect-SwiftUI
//
//  Created by Nick Joliya on 06/12/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        HorizontalImageScrollView()
    }
}

#Preview {
    ContentView()
}
