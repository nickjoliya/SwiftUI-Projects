//
//  ScrollEffect_SwiftUIApp.swift
//  ScrollEffect-SwiftUI
//
//  Created by Nick Joliya on 06/12/24.
//

import SwiftUI

@main
struct ScrollEffect_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
