//
//  ButtonAnimationApp.swift
//  ButtonAnimation
//
//  Created by Nick Joliya on 13/12/24.
//

import SwiftUI

@main
struct ButtonAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
