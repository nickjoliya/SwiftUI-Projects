//
//  LiquidSpreadButton.swift
//  ButtonAnimation
//
//  Created by Nick Joliya on 13/12/24.
//

import SwiftUI

struct LiquidSpreadButtonsWithIcons: View {
    @State private var isExpanded = false
    @State private var rotationAngle: Double = 0 
    let buttons = [
        ("pencil", Color.green),
        ("trash", Color.red),
        ("paperplane", Color.orange),
        ("heart", Color.purple)
    ]

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Image("bgg")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()

                if isExpanded {
                    Color.black.opacity(0.4)
                        .ignoresSafeArea()
                        .onTapGesture {
                            isExpanded = false
                        }
                }

                ForEach(0..<buttons.count, id: \.self) { index in
                    Button(action: {
                        print("\(buttons[index].0) Button Tapped")
                    }) {
                        Image(systemName: buttons[index].0)
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(.white)
                            .frame(width: 50, height: 50)
                            .background(Circle().fill(Color.blue.opacity(0.5)))
                            .shadow(radius: 5)
                            .scaleEffect(isExpanded ? 1 : 0.5)
                            .opacity(isExpanded ? 1 : 0)
                    }
                    .offset(
                        x: 0,
                        y: isExpanded ? -CGFloat(index + 1) * 70 : 0
                    )
                    .position(x: 70, y: geometry.size.height - 80) // Start at main button's position
                    .animation(
                        .spring(response: 0.6, dampingFraction: 0.5, blendDuration: 0.2)
                            .delay(Double(index) * 0.1),
                        value: isExpanded
                    )
                }

                // Main Button (Fixed at Bottom-Left)
                Button(action: {
                    toggleExpansion()
                }) {
                    Circle()
                        .fill(Color.blue.opacity(0.7))
                        .frame(width: 60, height: 60)
                        .overlay(
                            Image(systemName: isExpanded ? "xmark" : "plus")
                                .font(.system(size: 24, weight: .bold))
                                .foregroundColor(.white)
                        )
                        .shadow(radius: 10)
                        .rotationEffect(.degrees(rotationAngle)) // Rotate the button
                        .animation(.spring(response: 0.5, dampingFraction: 0.7), value: rotationAngle) // Smooth animation
                }
                .position(x: 70, y: geometry.size.height - 80) // Bottom-Left Position
            }
        }
    }

    private func toggleExpansion() {
        // Update rotation angle for animation
        rotationAngle += isExpanded ? -180 :  180 // Rotate 180° each time the button is clicked
        isExpanded.toggle() // Expand/Collapse buttons
    }
}

struct LiquidSpreadButtonsWithIcons_Previews: PreviewProvider {
    static var previews: some View {
        LiquidSpreadButtonsWithIcons()
            .previewDevice("iPhone 14")
    }
}

