//
//  SpaceNews_APIApp.swift
//  SpaceNews-API
//
//  Created by Rajesh Shiyal on 21/10/24.
//

import SwiftUI

@main
struct SpaceNews_APIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
