//
//  NavigationDemoAppApp.swift
//  NavigationDemoApp
//
//  Created by Nick Joliya on 05/01/25.
//

import SwiftUI

@main
struct NavigationDemoAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
