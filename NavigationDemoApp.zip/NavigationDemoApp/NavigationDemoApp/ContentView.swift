//
//  ContentView.swift
//  NavigationDemoApp
//
//  Created by Nick Joliya on 05/01/25.
//

import SwiftUI

struct ContentView: View {
    var navigationTypes = [
        "NavigationLink",
        "Sheet",
        "Full Screen Cover",
        "Popover",
        "Custom Transition"
    ]
    
    @State private var path: [String] = []
    @State private var showSheet = false
    @State private var showFullScreen = false
    @State private var showPopover = false
    @State private var showCustomTransition = false
    
    var body: some View {
        NavigationStack(path: $path) {
            ZStack {
                LinearGradient(
                    colors: [Color.blue, Color.purple],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                VStack(spacing: 20) {
                    Text("Navigation Types")
                        .font(.largeTitle.bold())
                        .foregroundColor(.white)
                        .shadow(color: .black.opacity(0.2), radius: 5, x: 0, y: 5)
                    
                    ScrollView {
                        ForEach(navigationTypes, id: \.self) { type in
                            Button(action: { handleNavigation(type: type) }) {
                                Text(type)
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(
                                        LinearGradient(
                                            colors: [Color.orange, Color.red],
                                            startPoint: .top,
                                            endPoint: .bottom
                                        )
                                    )
                                    .cornerRadius(12)
                                    .shadow(color: Color.black.opacity(0.3), radius: 8, x: 0, y: 6)
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 8)
                        }
                    }
                }
            }
            .navigationDestination(for: String.self) { type in
                DestinationView(title: type)
            }
            .sheet(isPresented: $showSheet) {
                DestinationView(title: "Sheet", showBackButton: true)
            }
            .fullScreenCover(isPresented: $showFullScreen) {
                DestinationView(title: "Full Screen Cover", showBackButton: true)
            }
            .overlay(
                            customPopover()
                        )
            .overlay {
                if showCustomTransition {
                    CustomTransitionView(isActive: $showCustomTransition)
                        .transition(.move(edge: .leading))
                        .animation(.easeInOut, value: showCustomTransition)
                }
            }
        }
    }
    
    private func handleNavigation(type: String) {
        switch type {
        case "Sheet": showSheet.toggle()
        case "Full Screen Cover": showFullScreen.toggle()
        case "Popover": showPopover.toggle()
        case "Custom Transition": withAnimation { showCustomTransition = true }
        default: path.append(type)
        }
    }
    @ViewBuilder
       private func customPopover() -> some View {
           if showPopover {
               ZStack {
                   // Background Dimmer
                   Color.black.opacity(0.4)
                       .ignoresSafeArea()
                       .onTapGesture {
                           withAnimation {
                               showPopover.toggle()
                           }
                       }
                   
                   // Popover Content
                   VStack(spacing: 20) {
                       Text("Popover")
                           .font(.title.bold())
                           .foregroundColor(.white)
                           .padding(.top)
                       
                       Text("This is a custom popover implementation.")
                           .font(.body)
                           .foregroundColor(.white.opacity(0.8))
                           .multilineTextAlignment(.center)
                           .padding(.horizontal)
                       
                       Button(action: {
                           withAnimation {
                               showPopover.toggle()
                           }
                       }) {
                           Text("Dismiss")
                               .font(.headline)
                               .foregroundColor(.white)
                               .padding()
                               .frame(maxWidth: .infinity)
                               .background(Color.red)
                               .cornerRadius(10)
                               .shadow(radius: 5)
                       }
                       .padding(.horizontal, 20)
                       .padding(.bottom, 20)
                   }
                   .frame(width: 300)
                   .background(LinearGradient(colors: [Color.teal, Color.green], startPoint: .top, endPoint: .bottom))
                   .cornerRadius(16)
                   .shadow(radius: 20)
                   .transition(.scale)
                   .animation(.spring(), value: showPopover)
               }
           }
       }
}

struct DestinationView: View {
    let title: String
    var showBackButton: Bool = false
    
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color.pink, Color.purple],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            VStack {
                if showBackButton {
                    HStack {
                        Button(action: {
                            withAnimation {
                                dismiss()
                            }
                        }) {
                            HStack {
                                Image(systemName: "chevron.left")
                            }
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Circle().fill(Color.black.opacity(0.2)))
                            .cornerRadius(10)
                        }
                        .padding()
                        Spacer()
                    }
                }
                
                Spacer()
                
                Text(title)
                    .font(.largeTitle.bold())
                    .foregroundColor(.white)
                    .padding()
                    .shadow(color: .black.opacity(0.5), radius: 10, x: 0, y: 10)
                
                Text("This is the \(title) screen.")
                    .font(.body)
                    .foregroundColor(.white.opacity(0.8))
                    .padding()
                
                Spacer()
            }
        }
    }
}

struct CustomTransitionView: View {
    @Binding var isActive: Bool
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color.green, Color.teal],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            VStack {
                HStack {
                    Button(action: {
                        withAnimation {
                            isActive = false
                        }
                    }) {
                        HStack {
                            Image(systemName: "chevron.left")
                        }
                        .foregroundColor(.white)
                        .padding(10)
                        .background(Circle().fill(Color.black.opacity(0.2)))
                        .cornerRadius(10)
                    }
                    .padding()
                    Spacer()
                }
                
                Spacer()
                
                Text("Custom Transition")
                    .font(.largeTitle.bold())
                    .foregroundColor(.white)
                    .padding()
                    .shadow(color: .black.opacity(0.5), radius: 10, x: 0, y: 10)
                
                Text("This screen uses a custom navigation approach.")
                    .font(.body)
                    .foregroundColor(.white.opacity(0.8))
                    .padding()
                
                Spacer()
            }
        }
    }
}

#Preview {
    ContentView()
}
