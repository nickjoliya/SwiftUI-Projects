//
//  RealisticSpaceView.swift
//  SpaceSwiftUI
//
//  Created by Nick Joliya on 19/12/24.
//


import SwiftUI

struct RealisticSpaceView: View {
    @State private var meteors = [Meteor]()
    @State private var fallingStars = [FallingStar]()
    
    var body: some View {
        ZStack {
            // Background color (Space)
            Color.black
                .edgesIgnoringSafeArea(.all)

            // Static Stars (Unchanged)
            ForEach(0..<200, id: \.self) { _ in
                Circle()
                    .fill(Color.white.opacity(Double.random(in: 0.5...1.0)))
                    .frame(width: CGFloat.random(in: 1...4))
                    .position(
                        x: CGFloat.random(in: 0...UIScreen.main.bounds.width),
                        y: CGFloat.random(in: 0...UIScreen.main.bounds.height)
                    )
            }.ignoresSafeArea()

            // Falling Stars (Changed to have random directions)
            ForEach(fallingStars) { star in
                FallingStarView(star: star)
            }

            // Falling Meteors (Rocket with fire tail)
//            ForEach(meteors) { meteor in
//                MeteorView(meteor: meteor)
//            }
        }
        .onAppear {
            addRandomFallingStars()
            addRandomMeteors()
        }
    }
    
    private func addRandomFallingStars() {
        Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { _ in
            withAnimation {
                let newStar = FallingStar(
                    id: UUID(),
                    startX: CGFloat.random(in: 0...UIScreen.main.bounds.width),
                    startY: CGFloat.random(in: -50...UIScreen.main.bounds.height),
                    size: CGFloat.random(in: 1...3),
                    duration: Double.random(in: 3...6),
                    angle: Double.random(in: 0...360)
                )
                fallingStars.append(newStar)

                DispatchQueue.main.asyncAfter(deadline: .now() + newStar.duration) {
                    fallingStars.removeAll { $0.id == newStar.id }
                }
            }
        }
    }
   
    private func addRandomMeteors() {
        Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { _ in
            withAnimation {
                let newMeteor = Meteor(
                    id: UUID(),
                    startX: CGFloat.random(in: -50...UIScreen.main.bounds.width / 2),
                    startY: CGFloat.random(in: -50...UIScreen.main.bounds.height / 2),
                    size: CGFloat.random(in: 8...14),
                    duration: Double.random(in: 2...4)
                )
                meteors.append(newMeteor)

                // Remove meteor after it completes its journey
                DispatchQueue.main.asyncAfter(deadline: .now() + newMeteor.duration) {
                    meteors.removeAll { $0.id == newMeteor.id }
                }
            }
        }
    }
}

struct MeteorView: View {
    let meteor: Meteor

    @State private var isAnimating = false

    var body: some View {
        ZStack {
            // Rocket Body (A larger, rectangular shape)
            RoundedRectangle(cornerRadius: 5)
                .fill(Color.white)
                .frame(width: 5, height: 5)
                .shadow(radius: 5)

            // Rocket Fire Tail
            LinearGradient(gradient: Gradient(colors: [Color.orange, Color.red, Color.yellow.opacity(0.5)]),
                           startPoint: .topTrailing,
                           endPoint: .bottomTrailing)
                .frame(width: meteor.size * 3, height: meteor.size)
                .cornerRadius(meteor.size)
                .opacity(0.7)
                .blur(radius: 5)
                .rotationEffect(.degrees(45))
                .offset(x: 10, y: 10) // Spreading effect to simulate fire

        }
        .position(x: isAnimating ? UIScreen.main.bounds.width + 50 : meteor.startX,
                  y: isAnimating ? UIScreen.main.bounds.height + 50 : meteor.startY)
        .onAppear {
            withAnimation(Animation.linear(duration: meteor.duration)) {
                isAnimating = true
            }
        }
    }
}

struct FallingStarView: View {
    let star: FallingStar
    
    @State private var isAnimating = false

    var body: some View {
        Circle()
            .fill(Color.white.opacity(0.8))
            .frame(width: star.size, height: star.size)
            .position(x: isAnimating ? UIScreen.main.bounds.width + 50 : star.startX,
                      y: isAnimating ? UIScreen.main.bounds.height + 50 : star.startY)
            .onAppear {
                withAnimation(Animation.linear(duration: star.duration).repeatForever(autoreverses: false)) {
                    isAnimating = true
                }
            }
            .rotationEffect(.degrees(star.angle)) // Falling in random angles
    }
}

struct Meteor: Identifiable {
    let id: UUID
    let startX: CGFloat
    let startY: CGFloat
    let size: CGFloat
    let duration: Double
}

struct FallingStar: Identifiable {
    let id: UUID
    let startX: CGFloat
    let startY: CGFloat
    let size: CGFloat
    let duration: Double
    let angle: Double
}

struct RealisticSpaceView_Previews: PreviewProvider {
    static var previews: some View {
        RealisticSpaceView()
    }
}
