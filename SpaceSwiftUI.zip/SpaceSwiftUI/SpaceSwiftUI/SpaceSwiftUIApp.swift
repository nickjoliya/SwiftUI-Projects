//
//  SpaceSwiftUIApp.swift
//  SpaceSwiftUI
//
//  Created by Nick Joliya on 19/12/24.
//

import SwiftUI

@main
struct SpaceSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
