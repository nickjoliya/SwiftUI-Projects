//
//  WaveLoadingAnimation.swift
//  WaveLoadingAnimation
//
//  Created by Nick Joliya on 16/12/24.
//

import SwiftUI

struct RealisticBottleFillingView: View {
    @State private var waveOffset: CGFloat = 0
    @State private var fillPercentage: CGFloat = 0.0

    var body: some View {
        ZStack {
            
            LinearGradient(
                gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.blue.opacity(0.1)]),
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack(spacing: 20) {
                // Percentage Display
                Text("\(Int(fillPercentage * 100))%")
                    .font(.system(size: 50, weight: .bold))
                    .foregroundColor(Color.black.opacity(0.8))
                    .padding()

                Spacer()

                ZStack {
                    // Bottle outline
                    RoundedRectangle(cornerRadius: 30)
                        .stroke(Color.gray.opacity(0.7), lineWidth: 5)
                        .frame(width: 200, height: 400)

                    // Filling waves
                    ZStack {
                        WaveShape(offset: waveOffset, amplitude: 10, frequency: 1.5)
                            .fill(Color.blue.opacity(0.6))
                            .frame(height: 400)
                            .offset(y: calculateWaveOffset(for: 200)) // Start at the bottom
                            .mask(
                                RoundedRectangle(cornerRadius: 30)
                                    .frame(width: 200, height: 400)
                            )
                            .animation(.easeInOut(duration: 5), value: fillPercentage)
                        WaveShape(offset: waveOffset, amplitude: 10, frequency: 2)
                            .fill(Color.blue.opacity(0.5))
                            .frame(height: 400)
                            .offset(y: calculateWaveOffset(for: 200)) // Start at the bottom
                            .mask(
                                RoundedRectangle(cornerRadius: 30)
                                    .frame(width: 200, height: 400)
                            )
                            .animation(.easeInOut(duration: 5), value: fillPercentage)

                        WaveShape(offset: waveOffset + .pi, amplitude: 8, frequency: 2.5)
                            .fill(Color.blue.opacity(0.3))
                            .frame(height: 400)
                            .offset(y: calculateWaveOffset(for: 200))
                            .mask(
                                RoundedRectangle(cornerRadius: 30)
                                    .frame(width: 200, height: 400)
                            )
                            .animation(.easeInOut(duration: 5), value: fillPercentage)
                        WaveShape(offset: waveOffset + .pi, amplitude: 8, frequency: 3)
                            .fill(Color.blue.opacity(0.2))
                            .frame(height: 400)
                            .offset(y: calculateWaveOffset(for: 200))
                            .mask(
                                RoundedRectangle(cornerRadius: 30)
                                    .frame(width: 200, height: 400)
                            )
                            .animation(.easeInOut(duration: 5), value: fillPercentage)
                    }
                }

                Spacer()
            }
        }
        .onAppear {
            // Start wave animation and filling progress
            withAnimation(.linear(duration: 2).repeatForever(autoreverses: false)) {
                waveOffset = .pi * 2
            }

            Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { timer in
                if fillPercentage < 1.0 {
                    fillPercentage += 0.01 // Gradual filling
                } else {
                    timer.invalidate() // Stop when fully filled
                }
            }
        }
    }

    // Calculate wave offset based on the bottle height and fill percentage
    private func calculateWaveOffset(for bottleHeight: CGFloat) -> CGFloat {
        bottleHeight * (1 - fillPercentage) // Offset reduces as the fill percentage increases
    }
}

struct WaveShape: Shape {
    var offset: CGFloat
    var amplitude: CGFloat
    var frequency: CGFloat

    var animatableData: CGFloat {
        get { offset }
        set { offset = newValue }
    }

    func path(in rect: CGRect) -> Path {
        var path = Path()
        let width = rect.width
        let midHeight = rect.height / 2

        path.move(to: CGPoint(x: 0, y: midHeight))

        for x in stride(from: 0, through: width, by: 1) {
            let relativeX = x / width
            let sine = sin(relativeX * frequency * .pi * 2 + offset)
            let y = midHeight + sine * amplitude
            path.addLine(to: CGPoint(x: x, y: y))
        }

        path.addLine(to: CGPoint(x: rect.width, y: rect.height))
        path.addLine(to: CGPoint(x: 0, y: rect.height))
        path.closeSubpath()

        return path
    }
}

struct RealisticBottleFillingView_Previews: PreviewProvider {
    static var previews: some View {
        RealisticBottleFillingView()
    }
}
