//
//  WaveLoadingAnimationApp.swift
//  WaveLoadingAnimation
//
//  Created by Nick Joliya on 16/12/24.
//

import SwiftUI

@main
struct WaveLoadingAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
