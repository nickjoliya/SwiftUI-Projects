//
//  Shimmer_Loading_EffectApp.swift
//  Shimmer Loading Effect
//
//  Created by Nick Joliya on 24/11/24.
//

import SwiftUI

@main
struct Shimmer_Loading_EffectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
