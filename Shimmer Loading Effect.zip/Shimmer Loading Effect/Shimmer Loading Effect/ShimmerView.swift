//
//  ShimmerView.swift
//  HeathCareUI
//
//  Created by Nick Joliya on 24/11/24.
//


import SwiftUI

// Custom Modifier for Shimmer Effect
struct ShimmerModifier: ViewModifier {
    @State private var phase: CGFloat = -1.0 // Start shimmer off-screen
    private let animationDuration: Double = 2.0 // Speed of shimmer
    private let gradientWidth: CGFloat = 0.5 // Width of the shimmer gradient

    func body(content: Content) -> some View {
        content
            .overlay(
                GeometryReader { geometry in
                    let shimmerGradient = LinearGradient(
                        gradient: Gradient(colors: [
                            Color.clear,
                            Color.white.opacity(0.8),
                            Color.clear
                        ]),
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                    
                    Rectangle()
                        .fill(shimmerGradient)
                        .rotationEffect(.degrees(15)) // Subtle rotation
                        .frame(width: geometry.size.width * gradientWidth)
                        .offset(x: phase * geometry.size.width)
                        .animation(Animation.easeInOut(duration: animationDuration).repeatForever(autoreverses: false), value: phase)
                }
            )
            .onAppear {
                phase = 2.0 // Move the shimmer across the content
            }
            .mask(content)
    }
}

// View Extension for Convenience
extension View {
    func shimmering() -> some View {
        self.modifier(ShimmerModifier())
    }
}


