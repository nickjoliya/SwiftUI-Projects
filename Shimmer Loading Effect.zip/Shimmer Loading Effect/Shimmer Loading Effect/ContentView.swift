//
//  ContentView.swift
//  Shimmer Loading Effect
//
//  Created by Nick Joliya on 24/11/24.
//

import SwiftUI
struct ContentView: View {
    @State private var isLoading = true

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            if isLoading {
                // Loading placeholders with shimmer
                ScrollView {
                    ForEach(0..<5) { _ in
                        HStack(spacing: 16) {
                            Circle()
                                .fill(Color.gray.opacity(0.3))
                                .frame(width: 50, height: 50)
                                .shimmering()
                            
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Loading...")
                                    .font(.title2)
                                    .foregroundColor(Color.gray.opacity(0.7))
                                    .shimmering()
                                
                                RoundedRectangle(cornerRadius: 4)
                                    .fill(Color.gray.opacity(0.3))
                                    .frame(height: 16)
                                    .shimmering()
                                
                                RoundedRectangle(cornerRadius: 4)
                                    .fill(Color.gray.opacity(0.3))
                                    .frame(height: 14)
                                    .shimmering()
                                
                                RoundedRectangle(cornerRadius: 4)
                                    .fill(Color.gray.opacity(0.3))
                                    .frame(width: 100, height: 14)
                                    .shimmering()
                              
                            }
                            Spacer()
                        }
                        .padding()
                    }
                }
            }
        }
        .padding()
        .onAppear {

        }
    }
}

// Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .previewDevice("iPhone 14 Pro")
    }
}
