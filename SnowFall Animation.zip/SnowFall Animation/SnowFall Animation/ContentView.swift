//
//  ContentView.swift
//  SnowFall Animation
//
//  Created by Nick Joliya on 27/11/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack{
            Color.orange.ignoresSafeArea()
            VStack{
                Spacer()
                Button(action: {
                    print("Button Pressed")
                }) {
                    Text("Snow Fall Animation")
                        .font(.title)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black)
                        .cornerRadius(10)
                }
                
            }
        }
    }
}

#Preview {
    ContentView()
}
