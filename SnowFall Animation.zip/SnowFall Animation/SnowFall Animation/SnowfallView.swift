//
//  RealisticSnowfallView.swift
//  SnowFall Animation
//
//  Created by Nick Joliya on 27/11/24.
//


import SwiftUI

struct SnowfallView: View {
    private let backgroundImage = "winter" 
    private let snowflakeCount = 300

    var body: some View {
        ZStack {
            
            Image(backgroundImage)
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)

            GeometryReader { geometry in
                ForEach(0..<snowflakeCount, id: \.self) { _ in
                    Snowflake()
                        .frame(width: CGFloat.random(in: 4...10), height: CGFloat.random(in: 4...10)) 
                        .position(
                            x: CGFloat.random(in: 0...geometry.size.width),
                            y: CGFloat.random(in: -200...geometry.size.height)
                        )
                        .animation(
                            Animation.linear(duration: Double.random(in: 6...12))
                                .repeatForever(autoreverses: false),
                            value: UUID()
                        )
                }
            }
        }
    }
}

// Snowflake Shape and Movement
struct Snowflake: View {
    @State private var yOffset: CGFloat = 0
    @State private var xDrift: CGFloat = 0

    var body: some View {
        Circle()
            .fill(Color.white.opacity(Double.random(in: 0.5...1.0))) // Random opacity
            .frame(width: Double.random(in: 5...9), height: Double.random(in: 5...9))
            .modifier(SnowfallAnimationModifier())
    }
}

struct SnowfallAnimationModifier: ViewModifier {
    @State private var yOffset: CGFloat = -1000
    @State private var xOffset: CGFloat = 0

    func body(content: Content) -> some View {
        content
            .offset(x: xOffset, y: yOffset)
            .onAppear {
                let driftAmount = CGFloat.random(in: -50...50) // Horizontal drift
                withAnimation(
                    Animation.linear(duration: Double.random(in: 6...12))
                        .repeatForever(autoreverses: false)
                ) {
                    yOffset = 2000 // Moves the snowflake downward
                    xOffset = driftAmount // Adds horizontal drifting
                }
            }
    }
}

// Preview
struct SnowfallView_Previews: PreviewProvider {
    static var previews: some View {
        SnowfallView()
    }
}
