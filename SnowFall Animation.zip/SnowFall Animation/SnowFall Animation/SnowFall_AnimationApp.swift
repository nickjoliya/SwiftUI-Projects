//
//  SnowFall_AnimationApp.swift
//  SnowFall Animation
//
//  Created by Nick Joliya on 27/11/24.
//

import SwiftUI

@main
struct SnowFall_AnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
