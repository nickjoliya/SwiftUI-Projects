//
//  SwiftUIListApp.swift
//  SwiftUIList
//
//  Created by Nick Joliya on 14/04/25.
//

import SwiftUI

@main
struct SwiftUIListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
