//
//  ContentView 2.swift
//  SwiftUIList
//
//  Created by Nick Joliya on 14/04/25.
//


import SwiftUI

struct ContentView: View {
    // List data stored in a State variable
    @State private var items = ["Apple", "Banana", "Cherry"]
    // New item input
    @State private var newItem = ""

    var body: some View {
        NavigationView {
            VStack {
                // Input field and Add button
                HStack {
                    TextField("New item", text: $newItem)
                        .textFieldStyle(RoundedBorderTextFieldStyle())

                    Button(action: addItem) {
                        Image(systemName: "plus") // Add icon
                            .padding(.horizontal, 8)
                    }
                }
                .padding()

                // Editable, reorderable, deletable List
                List {
                    ForEach(items.indices, id: \.self) { index in
                        TextField("Edit item", text: $items[index]) // Editable list item
                    }
                    .onDelete(perform: deleteItem) // Swipe-to-delete
                    .onMove(perform: moveItem)     // Drag-to-reorder
                }
                .listStyle(PlainListStyle())
            }
            .navigationTitle("Fruits") // Navigation bar title
            .toolbar {
                EditButton() // Toggles edit mode (for delete/reorder)
            }
        }
    }

    // Add item to the list
    func addItem() {
        if !newItem.isEmpty {
            items.append(newItem)
            newItem = "" // Clear input
        }
    }

    // Delete item at specified index
    func deleteItem(at offsets: IndexSet) {
        items.remove(atOffsets: offsets)
    }

    // Move item from source to destination
    func moveItem(from source: IndexSet, to destination: Int) {
        items.move(fromOffsets: source, toOffset: destination)
    }
}

// ✅ Preview for Canvas or Simulator
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

