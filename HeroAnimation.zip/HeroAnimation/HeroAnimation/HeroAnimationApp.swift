//
//  HeroAnimationApp.swift
//  HeroAnimation
//
//  Created by Nick Joliya on 18/12/24.
//

import SwiftUI

@main
struct HeroAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
