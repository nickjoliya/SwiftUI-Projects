//
//  Food.swift
//  HeroAnimation
//
//  Created by Nick Joliya on 18/12/24.
//


import SwiftUI

struct Food: Identifiable {
    let id = UUID()
    let name: String
    let description: String
    let imageName: String
    let price: String
    let calories: String
}

import SwiftUI

struct HeroAnimationExample: View {
    @State private var selectedFood: Food? = nil
    @Namespace private var animationNamespace

    let foodItems = [
        Food(name: "Sushi Platter", description: "A delightful platter of fresh sushi with a variety of flavors.", imageName: "sushi", price: "$25", calories: "400 kcal"),
        Food(name: "Burger Deluxe", description: "Juicy beef burger with cheese, lettuce, and a soft bun.", imageName: "burger", price: "$15", calories: "750 kcal"),
        Food(name: "Pasta Primavera", description: "Italian pasta with fresh vegetables and a creamy sauce.", imageName: "pasta", price: "$18", calories: "620 kcal"),
        Food(name: "Tacos Fiesta", description: "Spicy chicken tacos topped with guacamole and salsa.", imageName: "tacos", price: "$12", calories: "550 kcal")
    ]

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.gray.opacity(0.7), Color.black.opacity(0.7)]),
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
                .ignoresSafeArea()

            if let selectedFood = selectedFood {
                FoodDetailView(food: selectedFood, selectedFood: $selectedFood, namespace: animationNamespace)
            } else {
                ListView(foodItems: foodItems, selectedFood: $selectedFood, namespace: animationNamespace)
            }
        }
    }
}

struct ListView: View {
    let foodItems: [Food]
    @Binding var selectedFood: Food?
    var namespace: Namespace.ID

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Text("Explore Delicious Meals")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding(.top)

                ForEach(foodItems) { food in
                    Button(action: {
                        withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) {
                            selectedFood = food
                        }
                    }) {
                        HStack {
                            Image(food.imageName)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 80, height: 80)
                                //.clipShape(Circle())
                                .matchedGeometryEffect(id: "\(food.id)-image", in: namespace)

                            VStack(alignment: .leading, spacing: 8) {
                                Text(food.name)
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .matchedGeometryEffect(id: "\(food.id)-name", in: namespace)

                                Text(food.description)
                                    .font(.subheadline)
                                    .foregroundColor(.white.opacity(0.8))
                                    .lineLimit(2)

                                Text(food.price)
                                    .font(.subheadline)
                                    .foregroundColor(.green)
                                    .matchedGeometryEffect(id: "\(food.id)-price", in: namespace)
                            }
                            .padding(.leading, 8)

                            Spacer()
                        }
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 18)
                                .fill(Color.black.opacity(0.2))
                                .shadow(radius: 10)
                                .matchedGeometryEffect(id: "\(food.id)-background", in: namespace)
                        )
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
            .padding(.horizontal)
        }
    }
}

struct FoodDetailView: View {
    var food: Food
    @Binding var selectedFood: Food?
    var namespace: Namespace.ID

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                ZStack(alignment: .topTrailing) {
                    Image(food.imageName)
                        .resizable()
                        .scaledToFit()
                        .frame(height: 300)
                        .clipShape(RoundedRectangle(cornerRadius: 25))
                        .shadow(radius: 10)
                        .matchedGeometryEffect(id: "\(food.id)-image", in: namespace)

                    // Close Button
                    Button(action: {
                        withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                            selectedFood = nil
                        }
                    }) {
                        Circle()
                            .fill(Color.white)
                            .frame(width: 40, height: 40)
                            .shadow(radius: 5)
                            .overlay(
                                Image(systemName: "xmark")
                                    .foregroundColor(.black)
                            )
                    }
                    //.padding()
                }

                VStack(alignment: .leading, spacing: 20) {
                    Text(food.name)
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .matchedGeometryEffect(id: "\(food.id)-name", in: namespace)

                    Text(food.description)
                        .font(.body)
                        .foregroundColor(.white.opacity(0.8))

                    HStack {
                        Text("Price: \(food.price)")
                            .font(.headline.bold())
                            .foregroundColor(.green)
                            .matchedGeometryEffect(id: "\(food.id)-price", in: namespace)

                        Spacer()

                        Text("Calories: \(food.calories)")
                            .font(.subheadline.bold())
                            .foregroundColor(.orange)
                    }

                    Divider()
                        .background(Color.white)

                    Text("Ingredients")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.bottom, 5)

                    VStack(alignment: .leading, spacing: 5) {
                        Text("• Fresh Ingredients")
                        Text("• Authentic Spices")
                        Text("• High-Quality Proteins")
                    }
                    .foregroundColor(.white.opacity(0.8))

                    Spacer()

                    Button(action: {
                        print("Order Now tapped for \(food.name)")
                    }) {
                        Text("Order Now")
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(12)
                            .shadow(radius: 5)
                    }
                }
                .padding()
                .padding(.bottom, 60)
                .background(
                    RoundedRectangle(cornerRadius: 30)
                        .fill(Color.black.opacity(0.2))
                        .shadow(radius: 10)
                )
                //.padding()
            }
        }
    }
}

struct HeroAnimationExample_Previews: PreviewProvider {
    static var previews: some View {
        HeroAnimationExample()
    }
}
