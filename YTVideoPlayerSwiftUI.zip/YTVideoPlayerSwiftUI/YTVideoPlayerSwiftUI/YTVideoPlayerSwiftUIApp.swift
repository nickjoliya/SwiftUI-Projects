//
//  YTVideoPlayerSwiftUIApp.swift
//  YTVideoPlayerSwiftUI
//
//  Created by Nick Joliya on 05/03/25.
//

import SwiftUI

@main
struct YTVideoPlayerSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
