//
//  ContentView.swift
//  YTVideoPlayerSwiftUI
//
//  Created by Nick Joliya on 05/03/25.
//

import SwiftUI

struct ContentView: View {

    var body: some View {
        VStack {
            // Main Video Player
            YouTubePlayerView(videoID: "kJQP7kiw5Fk") // Main playing video
                .aspectRatio(16/9, contentMode: .fit)
                .cornerRadius(10)
                .padding(.horizontal)
                .shadow(radius: 5)

            // Video Details
            VStack(alignment: .leading, spacing: 5) {
                Text("Most Viewed Video on YouTube")
                    .font(.title2).bold()
                
                Text("Despacito • 8.3B views • 4 years ago")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                
                Divider()
            }
            .padding(.horizontal)

            // Suggested Videos
            ScrollView {
                VStack(alignment: .leading) {
                    Text("Up Next")
                        .font(.title3).bold()
                        .padding(.horizontal)

                    ForEach(suggestedVideos, id: \.0) { videoID, title, channel, views in
                        HStack {
                            YouTubePlayerView(videoID: videoID) // Suggested video
                                .frame(width: 150, height: 90)
                                .cornerRadius(8)
                            
                            VStack(alignment: .leading) {
                                Text(title)
                                    .font(.headline)
                                    .lineLimit(2)
                                
                                Text("\(channel) • \(views)")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                            Spacer()
                        }
                        .padding(.horizontal)
                        .padding(.vertical, 5)
                    }
                }
            }
        }
    }
    
    let suggestedVideos = [
        ("sZSlTDlo0Ag", "SwiftUI Tutorial", "CodeWithChris", "1.2M views • 2 weeks ago"),
        ("UNH0bE4zPtY", "iOS Development", "iOS Academy", "560K views • 1 month ago"),
        ("tk-DxKw7080", "Apple Keynote", "Apple", "10M views • 3 days ago"),
        ("HxtLlByaYTc", "Swift Concurrency Explained", "Sean Allen", "320K views • 5 days ago"),
        ("MQtMaXBt2zM", "Combine Framework Basics", "Kavsoft", "120K views • 1 month ago")
    ]
}

#Preview {
    ContentView()
}
