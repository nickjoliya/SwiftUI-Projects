//
//  SplashScreen_SwftUIApp.swift
//  SplashScreen-SwftUI
//
//  Created by Rajesh Shiyal on 20/10/24.
//

import SwiftUI

@main
struct SplashScreen_SwftUIApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView()
        }
    }
}
