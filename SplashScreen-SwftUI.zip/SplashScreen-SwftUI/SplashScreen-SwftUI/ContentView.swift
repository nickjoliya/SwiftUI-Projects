//
//  ContentView.swift
//  SplashScreen-SwftUI
//
//  Created by Rajesh Shiyal on 20/10/24.
//

import SwiftUI

struct ContentView: View {
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var isPasswordVisible: Bool = false

    var body: some View {
        VStack {
            Text("Welcome!")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.top, 50)

            Text("Please sign in to your account")
                .font(.subheadline)
                .foregroundColor(.gray)
                .padding(.bottom, 40)

            VStack(spacing: 15) {
                TextField("Email", text: $email)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                    .padding(.horizontal)

                HStack {
                    if isPasswordVisible {
                        TextField("Password", text: $password)
                    } else {
                        SecureField("Password", text: $password)
                    }
                    Button(action: {
                        isPasswordVisible.toggle()
                    }) {
                        Image(systemName: isPasswordVisible ? "eye.fill" : "eye.slash.fill")
                            .foregroundColor(.gray)
                    }
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(10)
                .padding(.horizontal)

                Button(action: {
                    // Handle login action
                }) {
                    Text("Log In")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.orange)
                        .cornerRadius(10)
                        .padding(.top, 20)
                        .padding(.horizontal)
                }
            }

            Spacer()

            HStack {
                Text("Don't have an account?")
                    .font(.footnote)

                Button(action: {
                    // Handle sign-up action
                }) {
                    Text("Sign Up")
                        .font(.footnote)
                        .foregroundColor(.orange)
                }
            }
            .padding(.bottom, 30)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(20)
        //.shadow(radius: 10)
        .padding()
        .navigationBarHidden(true)
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

