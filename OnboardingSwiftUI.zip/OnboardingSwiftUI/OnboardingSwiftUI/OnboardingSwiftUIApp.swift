//
//  OnboardingSwiftUIApp.swift
//  OnboardingSwiftUI
//
//  Created by Nick on 17/12/25.
//

import SwiftUI

@main
struct OnboardingSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            OnboardingFlowView(onFinish: {
                print("Onboarding finished")
            })
        }
    }
}
