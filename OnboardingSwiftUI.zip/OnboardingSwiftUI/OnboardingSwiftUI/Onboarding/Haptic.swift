//
//  Haptic.swift
//  NutraLifeAI
//
//  Created by Nick on 16/12/25.
//


import UIKit

enum Haptic {
    static func light() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }
}
