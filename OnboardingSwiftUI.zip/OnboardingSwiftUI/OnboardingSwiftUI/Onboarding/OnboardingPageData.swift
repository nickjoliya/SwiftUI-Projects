//
//  OnboardingPageData.swift
//  NutraLifeAI
//
//  Created by Nick on 16/12/25.
//


import SwiftUI

struct OnboardingPageData {
    let title: String
    let description: String
    let image: Image
    let themeColor: Color
}
