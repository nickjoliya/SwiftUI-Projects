//
//  OnboardingProgressButton.swift
//  NutraLifeAI
//
//  Created by Nick on 16/12/25.
//


import SwiftUI

struct OnboardingProgressButton: View {

    let progress: CGFloat      // 0.0 → 1.0
    let themeColor: Color
    let onTap: () -> Void

    @State private var pressed = false

    var body: some View {
        Button(action: handleTap) {
            ZStack {
                // Inner button
                Circle()
                    .fill(themeColor)
                    .frame(width: 64, height: 64)

                Image(systemName: "arrow.right")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.white)

                // Progress ring
                Circle()
                    .trim(from: 0, to: progress)
                    .stroke(
                        AngularGradient(
                            gradient: Gradient(colors: [
                                themeColor.opacity(0.4),
                                themeColor,
                                themeColor.opacity(0.4)
                            ]),
                            center: .center
                        ),
                        style: StrokeStyle(
                            lineWidth: 4,
                            lineCap: .round
                        )
                    )
                    .frame(width: 74, height: 74)
                    .rotationEffect(.degrees(-90))
                    .animation(.easeInOut(duration: 0.4), value: progress)
            }
            .scaleEffect(pressed ? 0.92 : 1)
            .opacity(pressed ? 0.85 : 1)
            .animation(.easeInOut(duration: 0.15), value: pressed)
        }
    }

    private func handleTap() {
        pressed = true
        Haptic.light()

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) {
            pressed = false
            onTap()
        }
    }
}
