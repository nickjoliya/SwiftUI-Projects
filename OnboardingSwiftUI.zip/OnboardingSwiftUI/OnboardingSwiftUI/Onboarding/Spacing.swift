//
//  Spacing.swift
//  NutraLifeAI
//
//  Created by Nick on 16/12/25.
//


import SwiftUI

enum Spacing {
    static let sm: CGFloat = 8
    static let md: CGFloat = 16
    static let lg: CGFloat = 24
    static let xl: CGFloat = 32
}
