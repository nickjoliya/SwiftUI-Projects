//
//  OnboardingPageView.swift
//  NutraLifeAI
//
//  Created by Nick on 16/12/25.
//


import SwiftUI
import UIKit

struct OnboardingPageView: View {

    // MARK: - Inputs
    let title: String
    let description: String
    let image: Image
    let themeColor: Color
    let progress: CGFloat
    let onNext: () -> Void
    

    // MARK: - State
    @State private var buttonPressed = false
    @State private var floatImage = false
    @State private var bobOffset: CGFloat = 0


    var body: some View {
        ZStack {
            // 1️⃣ Floating bubbles (visible but subtle)
            BubbleBackground(
                themeColor: themeColor
            )

            // 2️⃣ Gradient overlay (TRANSPARENT, not opaque)
            LinearGradient(
                colors: [
                    Color.white.opacity(0.5),
                    themeColor.opacity(0.35)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            // MARK: - Foreground Content
            VStack(spacing: Spacing.lg) {
                Spacer()

                Text(title)
                    .font(.system(size: 32, weight: .bold))
                    .multilineTextAlignment(.center)

                Text(description)
                    .font(.system(size: 17))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)

                image
                    .resizable()
                    .scaledToFit()
                    .frame(maxHeight: 260)
                    .scaleEffect(floatImage ? 1.0 : 0.95)
                    .offset(y: bobOffset)
                    .shadow(color: themeColor.opacity(0.25), radius: 8, x: 0, y: 6)
                    .animation(.spring(response: 0.5, dampingFraction: 0.8), value: floatImage)

                Spacer()

                // ✅ NEW BUTTON (same place as old one)
                OnboardingProgressButton(
                    progress: progress,
                    themeColor: themeColor
                ) {
                    onNext()
                }
                .padding(.bottom, 32) // 👈 match old spacing
            }
            .padding(.horizontal)

        }
        .background(Color.clear.ignoresSafeArea())
        .onAppear {
            // Initial subtle scale-in
            floatImage = true

            // Start smooth bobbing: animate from 0 to 10 and back forever
            withAnimation(.easeInOut(duration: 2.0).repeatForever(autoreverses: true)) {
                bobOffset = 10
            }
        }
    }

    // MARK: - Actions
    private func handleNext() {
        Haptic.light()
        buttonPressed = true

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
            buttonPressed = false
            onNext()
        }
    }
}

