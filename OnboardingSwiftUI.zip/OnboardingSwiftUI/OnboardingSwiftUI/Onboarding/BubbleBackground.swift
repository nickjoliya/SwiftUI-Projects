//
//  BubbleBackground.swift
//  NutraLifeAI
//
//  Created by Nick on 16/12/25.
//


import SwiftUI

struct BubbleBackground: View {

    let themeColor: Color
    private let bubbleCount = 14

    var body: some View {
        GeometryReader { geo in
            ZStack {
                ForEach(0..<bubbleCount, id: \.self) { _ in
                    BubbleView(
                        themeColor: themeColor,
                        containerSize: geo.size
                    )
                }
            }
            .ignoresSafeArea()
        }
    }
}


struct BubbleView: View {

    let themeColor: Color
    let containerSize: CGSize

    // MARK: - Randomized (fixed per bubble)
    private let size: CGFloat = .random(in: 60...160)
    private let opacity: Double = .random(in: 0.08...0.18)
    private let speed: Double = .random(in: 18...36) // lower = faster
    private let startX: CGFloat
    private let startY: CGFloat

    @State private var yOffset: CGFloat = 0

    init(themeColor: Color, containerSize: CGSize) {
        self.themeColor = themeColor
        self.containerSize = containerSize

        // Start ANYWHERE on screen
        self.startX = .random(in: 0...containerSize.width)
        self.startY = .random(in: 0...containerSize.height)
    }

    var body: some View {
        Circle()
            .fill(
                LinearGradient(
                    colors: [
                        themeColor.opacity(opacity),
                        themeColor.opacity(opacity * 0.4)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .frame(width: size, height: size)
            .position(x: startX, y: startY)
            .offset(y: yOffset)
            .blur(radius: 2)
            .onAppear {
                // Move upward continuously
                withAnimation(
                    .linear(duration: speed)
                    .repeatForever(autoreverses: false)
                ) {
                    yOffset = -(containerSize.height + size)
                }
            }
    }
}
