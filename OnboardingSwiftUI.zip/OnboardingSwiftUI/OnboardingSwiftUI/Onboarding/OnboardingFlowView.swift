//
//  OnboardingFlowView.swift
//  NutraLifeAI
//
//  Created by Nick on 16/12/25.
//


import SwiftUI

struct OnboardingFlowView: View {

    let onFinish: () -> Void
    @State private var currentIndex = 0
    private var progress: CGFloat {
        CGFloat(currentIndex + 1) / CGFloat(pages.count)
    }


    private let pages: [OnboardingPageData] = [
        .init(
            title: "Scan Your Food",
            description: "Scan food labels or meals to understand what’s healthy.",
            image: Image(systemName: "camera.viewfinder"),
            themeColor: .green
        ),
        .init(
            title: "AI Health Insights",
            description: "Get simple, AI-powered nutrition insights instantly.",
            image: Image(systemName: "brain.head.profile"),
            themeColor: .blue
        ),
        .init(
            title: "Privacy First",
            description: "Your data stays on your device.",
            image: Image(systemName: "lock.shield"),
            themeColor: .teal
        )
    ]

    var body: some View {
        TabView(selection: $currentIndex) {
            ForEach(pages.indices, id: \.self) { index in
                OnboardingPageView(
                    title: pages[index].title,
                    description: pages[index].description,
                    image: pages[index].image,
                    themeColor: pages[index].themeColor,
                    progress: progress
                ) {
                    handleNext()
                }
                .tag(index)
                // 👇 KEY LINE
                .ignoresSafeArea()
            }
        }
        .tabViewStyle(.page(indexDisplayMode: .never))
        // 👇 ALSO IMPORTANT
        .ignoresSafeArea()
    }

    private func handleNext() {
        if currentIndex < pages.count - 1 {
            withAnimation {
                currentIndex += 1
            }
        } else {
            onFinish()
        }
    }
}

